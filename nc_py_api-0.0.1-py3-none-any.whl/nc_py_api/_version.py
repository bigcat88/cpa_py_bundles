""" Version of Nc_Py_Api """

__version__ = "0.0.1"
